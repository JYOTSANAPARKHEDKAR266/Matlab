function x=cfa_interp(z)

x=demosaic(uint8(z),"grbg");
end